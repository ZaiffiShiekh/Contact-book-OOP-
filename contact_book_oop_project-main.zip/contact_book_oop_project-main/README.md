main agenda of that project is to add contact book delete contact book

setup:
git clone https://github.com/your-username/folder_name.git
place all files in vs code and press run button

![image](https://github.com/runtime-error786/contact_book_oop_project/assets/123109871/b2df1af7-b514-43fb-ad2f-3f0f1da15d3d)
