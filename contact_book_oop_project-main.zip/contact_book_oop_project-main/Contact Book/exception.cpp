#include "exception.h"

void runtime_error :: what()
{
    std::cout<<"You entered the wrong input"<<std::endl;
}
